// tetris.cpp: ���������� ����� ����� ��� ����������� ����������.
//

#include "stdafx.h"
#include <Windows.h>
#include <iostream>
#include <vector>
#include <random>

using namespace std;

void SetColor(int text, int bg) {
	HANDLE hStdOut = GetStdHandle(STD_OUTPUT_HANDLE);
	SetConsoleTextAttribute(hStdOut, (WORD)((bg << 4) | text));
}

class Figures
{
protected:
	vector <string> BaseFigure = { "#", "#", "#", "#" };
public:

	Figures();
	~Figures();
	/*virtual void paint(int x, int y);*/
	virtual void paint1(int x, int y) { cout << " "; };
	
private:

};
Figures square, stick, T, Z, invertedZ, L, invertedL;
Figures::Figures()
{
	




}

Figures::~Figures()
{
}
class Pole
{
public:
	void print();
	Pole();
	~Pole();

private:

};

void Pole::print()
{
	SetColor(14, 0);
	
	COORD position = { 0,0 }; //������� x � y
	HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
	SetConsoleCursorPosition(hConsole, position);

	cout << "*******************************************\n";
	for (int i = 0; i < 43; i++) {
		for (int j = 0; j < 43; ++j) {
			if (j == 0 || j == 42)
				cout << "*";
			else
				cout << " ";
		}
		cout << "\n";
	}
	cout << "*******************************************\n";

	SetColor(7, 0);
}

Pole::Pole()
{
	
}

Pole::~Pole()
{
}
class Points
{
public:
	Points();
	~Points();

private:

};

Points::Points()
{
}

Points::~Points()
{
}
int main()
{

	
	Pole P;
	P.print(); 
	//for (;;) {
	//	P.print();
	//	Sleep(2000);
	//}
	system("pause");
    return 0;
}

